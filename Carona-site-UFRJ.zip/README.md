Para inicia o site inicia o arquivo app.py
